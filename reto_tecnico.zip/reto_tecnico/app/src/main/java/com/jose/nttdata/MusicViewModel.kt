package com.jose.nttdata

import androidx.databinding.Bindable
import androidx.databinding.Observable
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jose.nttdata.db.Music
import com.jose.nttdata.db.MusicRepository
import kotlinx.coroutines.launch

class MusicViewModel(private val repository: MusicRepository): ViewModel(), Observable {

    val musics= repository.music

    private var isUpdateOrDelete = false
    private lateinit var musicToUpdateOrDelete: Music

    @Bindable
    val inputName = MutableLiveData<String>()
    @Bindable
    val inputEmail = MutableLiveData<String>()
    @Bindable
    val saveOrUpdateButtonText = MutableLiveData<String>()
    @Bindable
    val clearAllOrDeleteButtonText = MutableLiveData<String>()

    private val statusMessage = MutableLiveData<Event<String>>()

    val message: LiveData<Event<String>>
        get() = statusMessage

    init {
        saveOrUpdateButtonText.value = "Guardar"
        clearAllOrDeleteButtonText.value = "Eliminar todo"
    }

    private fun resetForm() {
        inputName.value = null
        inputEmail.value = null
        isUpdateOrDelete = false
        saveOrUpdateButtonText.value = "Guardar"
        clearAllOrDeleteButtonText.value = "Eliminar todo"
    }

    fun saveOrUpdate() {
        if(inputName.value == null) {
            statusMessage.value = Event("Por favor ingresa el nombre de la canción")
        } else if(inputEmail.value == null) {
            statusMessage.value = Event("Por favor ingresa el nombre del artista")
        } else {
            if (isUpdateOrDelete) {
                musicToUpdateOrDelete.nameMusic = inputName.value!!
                musicToUpdateOrDelete.artista = inputEmail.value !!
                update(musicToUpdateOrDelete)
            } else {
                val name = inputName.value!!
                val email = inputEmail.value!!

                insert(Music(0, name, email))
            }

            inputName.value = null
            inputEmail.value = null
        }
    }

    fun clearAllOrDelete() {
        if (isUpdateOrDelete) {
            delete(musicToUpdateOrDelete)
        } else {
            clearAll()
        }
    }

    fun insert(music: Music) = viewModelScope.launch {
        val newRowId = repository.insert(music)
        if (newRowId > -1) {
            statusMessage.value = Event("Agregado correctamente $newRowId")
        } else {
            statusMessage.value = Event("Ocurrio un error")
        }
    }

    fun update(music: Music) = viewModelScope.launch {
        val numberOfRowsUpdated = repository.update(music)
        if (numberOfRowsUpdated > 0) {
            resetForm()
            statusMessage.value = Event("$numberOfRowsUpdated datos actualizados")
        } else {
            statusMessage.value = Event("Ocurrio un error")
        }
    }

    fun delete(music: Music) = viewModelScope.launch {
        val numberOfRowsDeleted = repository.delete(music)
        if (numberOfRowsDeleted > 0) {
            resetForm()
            statusMessage.value = Event("$numberOfRowsDeleted cancion eliminada")
        } else {
            statusMessage.value = Event("Ocurrio un error")
        }
    }

    fun clearAll() = viewModelScope.launch {
        val numberOfRowsDeleted = repository.deleteAll()
        if (numberOfRowsDeleted > 0) {
            statusMessage.value = Event("$numberOfRowsDeleted canciones eliminadas")
        } else {
            statusMessage.value = Event("Ocurrio un error")
        }
    }

    fun initUpdateAndDelete(music: Music) {
        inputName.value = music.nameMusic
        inputEmail.value = music.artista
        isUpdateOrDelete = true
        musicToUpdateOrDelete = music
        saveOrUpdateButtonText.value = "Actualiza"
        clearAllOrDeleteButtonText.value = "Eliminar"
    }

    override fun removeOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {
    }

    override fun addOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {
    }
}