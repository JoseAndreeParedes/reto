package com.jose.nttdata

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.jose.nttdata.databinding.ListItemBinding
import com.jose.nttdata.db.Music

class MusicAdapter(private val clickListener: (Music)->Unit)
    : RecyclerView.Adapter<MusicViewHolder>() {

    private val musicList = ArrayList<Music>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding: ListItemBinding = DataBindingUtil.inflate(layoutInflater, R.layout.list_item, parent, false)
        return MusicViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return musicList.size
    }

    override fun onBindViewHolder(holder: MusicViewHolder, position: Int) {
        holder.bind(musicList[position], clickListener)
    }

    fun setMusicList(music: List<Music>) {
        musicList.clear()
        musicList.addAll(music)
    }

}

class MusicViewHolder(val binding: ListItemBinding): RecyclerView.ViewHolder(binding.root) {
    fun bind(music: Music, clickListener: (Music)->Unit) {
        binding.nameTextView.text = music.nameMusic
        binding.emailTextView.text = music.artista
        binding.listItemLayout.setOnClickListener{
            clickListener(music)
        }
    }
}