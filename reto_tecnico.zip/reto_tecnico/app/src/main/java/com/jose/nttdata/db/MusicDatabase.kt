package com.jose.nttdata.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Music::class], version = 1)
abstract class MusicDatabase : RoomDatabase() {

    abstract val musicDAO: MusicDAO

    companion object {
        @Volatile
        private var INSTANCE: MusicDatabase? = null
        fun getInstance(context: Context): MusicDatabase {
            synchronized(this) {
                var instance: MusicDatabase? = INSTANCE
                if (instance == null) {
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        MusicDatabase::class.java,
                        "music_list"
                    ).build()
                }
                return instance
            }
        }
    }
}