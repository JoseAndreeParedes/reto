package com.jose.nttdata

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.jose.nttdata.databinding.ActivityMainBinding
import com.jose.nttdata.db.Music
import com.jose.nttdata.db.MusicDatabase
import com.jose.nttdata.db.MusicRepository

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var musicViewModel: MusicViewModel
    private lateinit var adapter: MusicAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        val dao = MusicDatabase.getInstance(application).musicDAO
        val repository = MusicRepository(dao)
        val factory = MusicViewModelFactory(repository)
        musicViewModel = ViewModelProvider(this, factory).get(MusicViewModel::class.java)
        binding.myViewModel = musicViewModel
        binding.lifecycleOwner = this
        initRecyclerView()
        musicViewModel.message.observe(this, Observer {
            it.getContentIfNotHandled()?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun initRecyclerView() {
        binding.musicRecyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MusicAdapter({ selectedItem: Music->listItemClicked(selectedItem)})
        binding.musicRecyclerView.adapter = adapter
        displayMusicList()
    }

    private fun displayMusicList() {
        musicViewModel.musics.observe(this, Observer {
            Log.i("MyTag", it.toString())
            adapter.setMusicList(it)
            adapter.notifyDataSetChanged()
        })
    }

    private fun listItemClicked(music: Music) {
        musicViewModel.initUpdateAndDelete(music)
    }
}