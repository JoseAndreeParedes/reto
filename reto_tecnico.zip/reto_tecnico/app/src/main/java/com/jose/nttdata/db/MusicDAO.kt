package com.jose.nttdata.db

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface MusicDAO {

    @Insert
    suspend fun insertMusic(music: Music): Long

    @Update
    suspend fun updateMusic(music: Music): Int

    @Delete
    suspend fun deleteMusic(music: Music): Int

    @Query(value = "delete from music_list")
    suspend fun deleteAll(): Int

    @Query(value = "select * from music_list")
    fun getAllMusic(): LiveData<List<Music>>
}