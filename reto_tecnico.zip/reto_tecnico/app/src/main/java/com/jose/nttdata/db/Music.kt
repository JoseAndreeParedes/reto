package com.jose.nttdata.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "music_list")
data class Music (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var Id: Int,
    @ColumnInfo(name = "Nombre_music")
    var nameMusic: String,
    @ColumnInfo(name = "Artista")
    var artista: String
)