package com.jose.nttdata.db

class MusicRepository(private val dao: MusicDAO) {

    val music = dao.getAllMusic();

    suspend fun insert(music: Music): Long {
        return dao.insertMusic(music)
    }

    suspend fun update(music: Music): Int {
        return dao.updateMusic(music)
    }

    suspend fun delete(music: Music): Int {
        return dao.deleteMusic(music)
    }

    suspend fun deleteAll(): Int {
        return dao.deleteAll()
    }
}